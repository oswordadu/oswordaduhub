"""
URL configuration for fake_review_detector project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.shortcuts import render

# This function renders the home page when the user visits '/'
def home(request):
    """Home page view"""
    return render(request, 'home.html')

# Main URL patterns for the project
urlpatterns = [
    # Admin panel URL
    path('admin/', admin.site.urls),
    # Home page URL
    path('', home, name='home'),
    # Scraper app URLs
    path('scraper/', include('scraper.urls')),
    # Payments app URLs
    path('payments/', include('payments.urls')),
]
