from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
from .scrapers import ReviewScraper, MockReviewScraper
from reviews.models import Review
from ml_model.detector import detect_single_review
import json
from django.db import models

# Create your views here.

# This function handles the main review scraping page.
def scrape_reviews(request):
    """View for scraping reviews from URLs"""
    # If the user submitted the form (POST request)
    if request.method == 'POST':
        # Get the URL and number of reviews from the form
        url = request.POST.get('url', '').strip()
        max_reviews = int(request.POST.get('max_reviews', 10))
        
        # If no URL is provided, show an error
        if not url:
            messages.error(request, 'Please provide a valid URL')
            return render(request, 'scraper/scrape.html')
        
        try:
            # Use a mock scraper to simulate scraping reviews
            scraper = MockReviewScraper()
            scraped_reviews = scraper.scrape_reviews(url, max_reviews)
            
            # Analyze each review for fakeness
            processed_reviews = []
            for review_data in scraped_reviews:
                # Use the ML model to detect if the review is fake
                detection_result = detect_single_review(review_data['review_text'])
                
                # Save the review to the database
                review = Review.objects.create(
                    product_id=review_data['product_id'],
                    reviewer=review_data['reviewer'],
                    rating=review_data['rating'],
                    review_text=review_data['review_text'],
                    date=review_data['date'],
                    is_fake=detection_result['is_fake'],
                    confidence_score=detection_result['confidence_score']
                )
                
                processed_reviews.append({
                    'review': review,
                    'detection_result': detection_result
                })
            # Show a success message and the results
            messages.success(request, f'Successfully scraped and analyzed {len(processed_reviews)} reviews')
            return render(request, 'scraper/scrape.html', {
                'processed_reviews': processed_reviews,
                'url': url
            })
        except Exception as e:
            # If something goes wrong, show an error
            messages.error(request, f'Error scraping reviews: {str(e)}')
            return render(request, 'scraper/scrape.html')
    # If GET request, just show the empty form
    return render(request, 'scraper/scrape.html')

# This function provides an API endpoint for scraping reviews (for use with JavaScript or other apps)
@csrf_exempt
def api_scrape_reviews(request):
    """API endpoint for scraping reviews"""
    if request.method == 'POST':
        try:
            # Parse the JSON body
            data = json.loads(request.body)
            url = data.get('url', '').strip()
            max_reviews = int(data.get('max_reviews', 10))
            
            if not url:
                return JsonResponse({'error': 'URL is required'}, status=400)
            # Use mock scraper for demo
            scraper = MockReviewScraper()
            scraped_reviews = scraper.scrape_reviews(url, max_reviews)
            # Analyze and save each review
            results = []
            for review_data in scraped_reviews:
                detection_result = detect_single_review(review_data['review_text'])
                review = Review.objects.create(
                    product_id=review_data['product_id'],
                    reviewer=review_data['reviewer'],
                    rating=review_data['rating'],
                    review_text=review_data['review_text'],
                    date=review_data['date'],
                    is_fake=detection_result['is_fake'],
                    confidence_score=detection_result['confidence_score']
                )
                results.append({
                    'id': review.id,
                    'reviewer': review.reviewer,
                    'rating': review.rating,
                    'review_text': review.review_text,
                    'is_fake': review.is_fake,
                    'confidence_score': review.confidence_score,
                    'verified': review.verified
                })
            # Return the results as JSON
            return JsonResponse({
                'success': True,
                'reviews': results,
                'total_reviews': len(results),
                'fake_reviews': len([r for r in results if r['is_fake']])
            })
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    # If not POST, return error
    return JsonResponse({'error': 'Invalid request method'}, status=405)

# This function shows the analysis dashboard for all reviews

def review_analysis(request):
    """View for analyzing existing reviews"""
    # Get all reviews from the database
    reviews = Review.objects.all().order_by('-date')
    # Calculate statistics for the dashboard
    total_reviews = reviews.count()
    fake_reviews = reviews.filter(is_fake=True).count()
    real_reviews = reviews.filter(is_fake=False).count()
    verified_reviews = reviews.filter(verified=True).count()
    # Calculate average confidence scores
    fake_confidence_avg = reviews.filter(is_fake=True).aggregate(
        avg=models.Avg('confidence_score')
    )
    avg_confidence_fake = fake_confidence_avg['avg'] if fake_confidence_avg['avg'] is not None else 0
    real_confidence_avg = reviews.filter(is_fake=False).aggregate(
        avg=models.Avg('confidence_score')
    )
    avg_confidence_real = real_confidence_avg['avg'] if real_confidence_avg['avg'] is not None else 0
    # Prepare context for the template
    context = {
        'reviews': reviews,
        'total_reviews': total_reviews,
        'fake_reviews': fake_reviews,
        'real_reviews': real_reviews,
        'verified_reviews': verified_reviews,
        'fake_percentage': (fake_reviews / total_reviews * 100) if total_reviews > 0 else 0,
        'avg_confidence_fake': round(avg_confidence_fake, 2),
        'avg_confidence_real': round(avg_confidence_real, 2)
    }
    # Render the analysis page
    return render(request, 'scraper/analysis.html', context)
