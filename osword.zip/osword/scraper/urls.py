from django.urls import path
from . import views

app_name = 'scraper'

# This file defines the URLs for the scraper app.
urlpatterns = [
    # Main page for scraping reviews
    path('', views.scrape_reviews, name='scrape'),
    # API endpoint for scraping reviews (for use with JavaScript or other apps)
    path('api/scrape/', views.api_scrape_reviews, name='api_scrape'),
    # Page for viewing review analysis dashboard
    path('analysis/', views.review_analysis, name='analysis'),
] 