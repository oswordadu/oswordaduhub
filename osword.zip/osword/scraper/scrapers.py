import requests
from bs4 import BeautifulSoup
import re
import time
import random
from datetime import datetime
from urllib.parse import urlparse, parse_qs
import json

class ReviewScraper:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
    
    def scrape_amazon_reviews(self, product_url, max_reviews=10):
        """Scrape reviews from Amazon product pages"""
        reviews = []
        
        try:
            # Extract product ID from URL
            product_id = self._extract_amazon_product_id(product_url)
            if not product_id:
                return reviews
            
            # Construct reviews URL
            reviews_url = f"https://www.amazon.com/product-reviews/{product_id}"
            
            response = self.session.get(reviews_url)
            if response.status_code != 200:
                return reviews
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Find review containers
            review_containers = soup.find_all('div', {'data-hook': 'review'})
            
            for container in review_containers[:max_reviews]:
                try:
                    # Extract reviewer name
                    reviewer_elem = container.find('span', {'class': 'a-profile-name'})
                    reviewer = reviewer_elem.text.strip() if reviewer_elem else "Anonymous"
                    
                    # Extract rating
                    rating_elem = container.find('i', {'class': 'a-icon-star'})
                    rating_text = rating_elem.get('class', [''])[-1] if rating_elem else ""
                    rating = self._extract_rating_from_class(rating_text)
                    
                    # Extract review text
                    review_text_elem = container.find('span', {'data-hook': 'review-body'})
                    review_text = review_text_elem.text.strip() if review_text_elem else ""
                    
                    # Extract date
                    date_elem = container.find('span', {'data-hook': 'review-date'})
                    date_text = date_elem.text.strip() if date_elem else ""
                    review_date = self._parse_amazon_date(date_text)
                    
                    if review_text:  # Only add if review text exists
                        reviews.append({
                            'product_id': product_id,
                            'reviewer': reviewer,
                            'rating': rating,
                            'review_text': review_text,
                            'date': review_date,
                            'source': 'amazon'
                        })
                
                except Exception as e:
                    print(f"Error parsing review: {e}")
                    continue
            
            # Add delay to be respectful
            time.sleep(random.uniform(1, 3))
            
        except Exception as e:
            print(f"Error scraping Amazon reviews: {e}")
        
        return reviews
    
    def scrape_generic_reviews(self, url, max_reviews=10):
        """Generic scraper for review-like content"""
        reviews = []
        
        try:
            response = self.session.get(url)
            if response.status_code != 200:
                return reviews
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Look for common review patterns
            review_patterns = [
                {'class': 'review'},
                {'class': 'comment'},
                {'class': 'feedback'},
                {'class': 'testimonial'},
                {'data-hook': 'review'},
                {'class': 'user-review'},
                {'class': 'product-review'}
            ]
            
            for pattern in review_patterns:
                review_elements = soup.find_all('div', pattern)
                if review_elements:
                    for element in review_elements[:max_reviews]:
                        try:
                            # Try to extract review text
                            text_elements = element.find_all(['p', 'span', 'div'])
                            review_text = ""
                            for text_elem in text_elements:
                                text = text_elem.get_text(strip=True)
                                if len(text) > 20:  # Likely review text
                                    review_text = text
                                    break
                            
                            if review_text:
                                reviews.append({
                                    'product_id': self._extract_domain_from_url(url),
                                    'reviewer': 'Anonymous',
                                    'rating': 3.0,  # Default rating
                                    'review_text': review_text,
                                    'date': datetime.now(),
                                    'source': 'generic'
                                })
                        
                        except Exception as e:
                            continue
            
        except Exception as e:
            print(f"Error scraping generic reviews: {e}")
        
        return reviews
    
    def _extract_amazon_product_id(self, url):
        """Extract Amazon product ID from URL"""
        try:
            # Handle different Amazon URL formats
            if '/dp/' in url:
                match = re.search(r'/dp/([A-Z0-9]{10})', url)
            elif '/product/' in url:
                match = re.search(r'/product/([A-Z0-9]{10})', url)
            else:
                return None
            
            return match.group(1) if match else None
        except:
            return None
    
    def _extract_rating_from_class(self, class_name):
        """Extract rating from CSS class name"""
        try:
            if 'a-star-5' in class_name:
                return 5.0
            elif 'a-star-4' in class_name:
                return 4.0
            elif 'a-star-3' in class_name:
                return 3.0
            elif 'a-star-2' in class_name:
                return 2.0
            elif 'a-star-1' in class_name:
                return 1.0
            else:
                return 3.0  # Default rating
        except:
            return 3.0
    
    def _parse_amazon_date(self, date_text):
        """Parse Amazon review date"""
        try:
            # Simple date parsing - in production, use dateutil
            if 'on' in date_text:
                date_part = date_text.split('on')[-1].strip()
                return datetime.strptime(date_part, '%B %d, %Y')
            else:
                return datetime.now()
        except:
            return datetime.now()
    
    def _extract_domain_from_url(self, url):
        """Extract domain name from URL"""
        try:
            parsed = urlparse(url)
            return parsed.netloc
        except:
            return 'unknown'

class MockReviewScraper:
    """Mock scraper for testing purposes"""
    
    def __init__(self):
        self.mock_reviews = [
            {
                'product_id': 'MOCK001',
                'reviewer': 'John Doe',
                'rating': 4.5,
                'review_text': 'This product is absolutely amazing! Best thing ever! 5 stars!',
                'date': datetime.now(),
                'source': 'mock'
            },
            {
                'product_id': 'MOCK001',
                'reviewer': 'Jane Smith',
                'rating': 3.0,
                'review_text': 'The product works as expected. Good quality for the price.',
                'date': datetime.now(),
                'source': 'mock'
            },
            {
                'product_id': 'MOCK001',
                'reviewer': 'Bob Johnson',
                'rating': 5.0,
                'review_text': 'Incredible quality, highly recommend to everyone!',
                'date': datetime.now(),
                'source': 'mock'
            },
            {
                'product_id': 'MOCK001',
                'reviewer': 'Alice Brown',
                'rating': 2.5,
                'review_text': 'It\'s okay, nothing special but gets the job done.',
                'date': datetime.now(),
                'source': 'mock'
            },
            {
                'product_id': 'MOCK001',
                'reviewer': 'Charlie Wilson',
                'rating': 4.0,
                'review_text': 'Perfect product, exceeded all expectations!',
                'date': datetime.now(),
                'source': 'mock'
            }
        ]
    
    def scrape_reviews(self, url, max_reviews=5):
        """Return mock reviews for testing"""
        return self.mock_reviews[:max_reviews] 