-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 18, 2025 at 05:50 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fake_review_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add review', 7, 'add_review'),
(26, 'Can change review', 7, 'change_review'),
(27, 'Can delete review', 7, 'delete_review'),
(28, 'Can view review', 7, 'view_review'),
(29, 'Can add payment', 8, 'add_payment'),
(30, 'Can change payment', 8, 'change_payment'),
(31, 'Can delete payment', 8, 'delete_payment'),
(32, 'Can view payment', 8, 'view_payment');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$600000$tBLEauF0AWfaYqvQQYM3V4$SN6NfQgx7kTwAn+XFybzupZjCqfOmy0C+u3cnAiFL2M=', '2025-07-15 02:21:31.494833', 1, 'osword', '', '', 'aduosword09@gmail.com', 1, 1, '2025-07-15 02:19:35.252060');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1, '2025-07-15 03:07:30.089059', '25', 'Charlie Wilson - MOCK001 (Fake)', 3, '', 7, 1),
(2, '2025-07-15 03:07:30.092769', '24', 'Alice Brown - MOCK001 (Real)', 3, '', 7, 1),
(3, '2025-07-15 03:07:30.095349', '23', 'Bob Johnson - MOCK001 (Fake)', 3, '', 7, 1),
(4, '2025-07-15 03:07:30.102000', '22', 'Jane Smith - MOCK001 (Real)', 3, '', 7, 1),
(5, '2025-07-15 03:07:30.105199', '21', 'John Doe - MOCK001 (Fake)', 3, '', 7, 1),
(6, '2025-07-15 03:07:30.107686', '20', 'Charlie Wilson - MOCK001 (Fake)', 3, '', 7, 1),
(7, '2025-07-15 03:07:30.110305', '19', 'Alice Brown - MOCK001 (Real)', 3, '', 7, 1),
(8, '2025-07-15 03:07:30.112779', '18', 'Bob Johnson - MOCK001 (Fake)', 3, '', 7, 1),
(9, '2025-07-15 03:07:30.115205', '17', 'Jane Smith - MOCK001 (Real)', 3, '', 7, 1),
(10, '2025-07-15 03:07:30.119101', '16', 'John Doe - MOCK001 (Fake)', 3, '', 7, 1),
(11, '2025-07-15 03:07:30.121601', '15', 'Charlie Wilson - MOCK001 (Fake)', 3, '', 7, 1),
(12, '2025-07-15 03:07:30.124238', '14', 'Alice Brown - MOCK001 (Real)', 3, '', 7, 1),
(13, '2025-07-15 03:07:30.126743', '13', 'Bob Johnson - MOCK001 (Fake)', 3, '', 7, 1),
(14, '2025-07-15 03:07:30.129407', '12', 'Jane Smith - MOCK001 (Real)', 3, '', 7, 1),
(15, '2025-07-15 03:07:30.131781', '11', 'John Doe - MOCK001 (Fake)', 3, '', 7, 1),
(16, '2025-07-15 03:07:30.135831', '10', 'Charlie Wilson - MOCK001 (Fake)', 3, '', 7, 1),
(17, '2025-07-15 03:07:30.138431', '9', 'Alice Brown - MOCK001 (Real)', 3, '', 7, 1),
(18, '2025-07-15 03:07:30.141089', '8', 'Bob Johnson - MOCK001 (Fake)', 3, '', 7, 1),
(19, '2025-07-15 03:07:30.143661', '7', 'Jane Smith - MOCK001 (Real)', 3, '', 7, 1),
(20, '2025-07-15 03:07:30.146216', '6', 'John Doe - MOCK001 (Fake)', 3, '', 7, 1),
(21, '2025-07-15 10:03:09.955265', '35', 'Charlie Wilson - MOCK001 (Fake)', 3, '', 7, 1),
(22, '2025-07-15 10:03:09.958228', '34', 'Alice Brown - MOCK001 (Real)', 3, '', 7, 1),
(23, '2025-07-15 10:03:09.960641', '33', 'Bob Johnson - MOCK001 (Fake)', 3, '', 7, 1),
(24, '2025-07-15 10:03:09.962936', '32', 'Jane Smith - MOCK001 (Real)', 3, '', 7, 1),
(25, '2025-07-15 10:03:09.965120', '31', 'John Doe - MOCK001 (Fake)', 3, '', 7, 1),
(26, '2025-07-15 10:03:09.972697', '30', 'Charlie Wilson - MOCK001 (Fake)', 3, '', 7, 1),
(27, '2025-07-15 10:03:09.975070', '29', 'Alice Brown - MOCK001 (Real)', 3, '', 7, 1),
(28, '2025-07-15 10:03:09.977343', '28', 'Bob Johnson - MOCK001 (Fake)', 3, '', 7, 1),
(29, '2025-07-15 10:03:09.979556', '27', 'Jane Smith - MOCK001 (Real)', 3, '', 7, 1),
(30, '2025-07-15 10:03:09.981869', '26', 'John Doe - MOCK001 (Fake)', 3, '', 7, 1),
(31, '2025-07-15 10:03:09.984945', '5', 'Charlie Wilson - MOCK001 (Fake)', 3, '', 7, 1),
(32, '2025-07-15 10:03:09.987885', '4', 'Alice Brown - MOCK001 (Real)', 3, '', 7, 1),
(33, '2025-07-15 10:03:09.990164', '3', 'Bob Johnson - MOCK001 (Fake)', 3, '', 7, 1),
(34, '2025-07-15 10:03:09.992486', '2', 'Jane Smith - MOCK001 (Real)', 3, '', 7, 1),
(35, '2025-07-15 10:03:09.994614', '1', 'John Doe - MOCK001 (Fake)', 3, '', 7, 1);

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(8, 'payments', 'payment'),
(7, 'reviews', 'review'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2025-07-15 01:44:08.537122'),
(2, 'auth', '0001_initial', '2025-07-15 01:44:09.127976'),
(3, 'admin', '0001_initial', '2025-07-15 01:44:09.271653'),
(4, 'admin', '0002_logentry_remove_auto_add', '2025-07-15 01:44:09.285274'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2025-07-15 01:44:09.303825'),
(6, 'contenttypes', '0002_remove_content_type_name', '2025-07-15 01:44:09.382525'),
(7, 'auth', '0002_alter_permission_name_max_length', '2025-07-15 01:44:09.453145'),
(8, 'auth', '0003_alter_user_email_max_length', '2025-07-15 01:44:09.476673'),
(9, 'auth', '0004_alter_user_username_opts', '2025-07-15 01:44:09.490461'),
(10, 'auth', '0005_alter_user_last_login_null', '2025-07-15 01:44:09.542434'),
(11, 'auth', '0006_require_contenttypes_0002', '2025-07-15 01:44:09.548967'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2025-07-15 01:44:09.562754'),
(13, 'auth', '0008_alter_user_username_max_length', '2025-07-15 01:44:09.586910'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2025-07-15 01:44:09.612898'),
(15, 'auth', '0010_alter_group_name_max_length', '2025-07-15 01:44:09.636640'),
(16, 'auth', '0011_update_proxy_permissions', '2025-07-15 01:44:09.652436'),
(17, 'auth', '0012_alter_user_first_name_max_length', '2025-07-15 01:44:09.677863'),
(18, 'reviews', '0001_initial', '2025-07-15 01:44:09.698269'),
(19, 'payments', '0001_initial', '2025-07-15 01:44:09.894888'),
(20, 'sessions', '0001_initial', '2025-07-15 01:44:09.976061');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('6pxa0w4gxm6l749k2pql3eqkri2rgk2y', '.eJxVjMsOwiAQRf-FtSFAy0OX7vsNZIYZpGogKe3K-O_apAvd3nPOfYkI21ri1nmJM4mL0OL0uyGkB9cd0B3qrcnU6rrMKHdFHrTLqRE_r4f7d1Cgl28NaAgUAxlls7eJnLEY_MCMlMcB6OyNzehDJhe0U0R6JAbgACrpZMT7AxX3OUA:1ubVIR:aKLeJnHe66mBDYWrjPsJgtqGueG8Tq5lAxifZvZPb1k', '2025-07-29 02:21:31.498627');

-- --------------------------------------------------------

--
-- Table structure for table `payments_payment`
--

CREATE TABLE `payments_payment` (
  `id` bigint(20) NOT NULL,
  `razorpay_order_id` varchar(100) NOT NULL,
  `razorpay_payment_id` varchar(100) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) NOT NULL,
  `payment_type` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `review_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reviews_review`
--

CREATE TABLE `reviews_review` (
  `id` bigint(20) NOT NULL,
  `product_id` varchar(100) NOT NULL,
  `reviewer` varchar(100) NOT NULL,
  `rating` double NOT NULL,
  `review_text` longtext NOT NULL,
  `date` datetime(6) NOT NULL,
  `is_fake` tinyint(1) NOT NULL,
  `confidence_score` double NOT NULL,
  `verified` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews_review`
--

INSERT INTO `reviews_review` (`id`, `product_id`, `reviewer`, `rating`, `review_text`, `date`, `is_fake`, `confidence_score`, `verified`) VALUES
(36, 'MOCK001', 'John Doe', 4.5, 'This product is absolutely amazing! Best thing ever! 5 stars!', '2025-07-15 09:31:03.906381', 1, 0.7503229099980595, 0),
(37, 'MOCK001', 'Jane Smith', 3, 'The product works as expected. Good quality for the price.', '2025-07-15 09:31:03.906395', 0, 0.7351746809413291, 0),
(38, 'MOCK001', 'Bob Johnson', 5, 'Incredible quality, highly recommend to everyone!', '2025-07-15 09:31:03.906398', 1, 0.6958059977760938, 0),
(39, 'MOCK001', 'Alice Brown', 2.5, 'It\'s okay, nothing special but gets the job done.', '2025-07-15 09:31:03.906401', 0, 0.6651660967092314, 0),
(40, 'MOCK001', 'Charlie Wilson', 4, 'Perfect product, exceeded all expectations!', '2025-07-15 09:31:03.906402', 1, 0.6665385526404196, 0),
(41, 'MOCK001', 'John Doe', 4.5, 'This product is absolutely amazing! Best thing ever! 5 stars!', '2025-07-15 11:22:03.521262', 1, 0.7503229099980595, 0),
(42, 'MOCK001', 'Jane Smith', 3, 'The product works as expected. Good quality for the price.', '2025-07-15 11:22:03.521288', 0, 0.7351746809413291, 0),
(43, 'MOCK001', 'Bob Johnson', 5, 'Incredible quality, highly recommend to everyone!', '2025-07-15 11:22:03.521293', 1, 0.6958059977760938, 0),
(44, 'MOCK001', 'Alice Brown', 2.5, 'It\'s okay, nothing special but gets the job done.', '2025-07-15 11:22:03.521297', 0, 0.6651660967092314, 0),
(45, 'MOCK001', 'Charlie Wilson', 4, 'Perfect product, exceeded all expectations!', '2025-07-15 11:22:03.521300', 1, 0.6665385526404196, 0),
(46, 'MOCK001', 'John Doe', 4.5, 'This product is absolutely amazing! Best thing ever! 5 stars!', '2025-07-15 13:09:03.854632', 1, 0.7503229099980595, 0),
(47, 'MOCK001', 'Jane Smith', 3, 'The product works as expected. Good quality for the price.', '2025-07-15 13:09:03.854637', 0, 0.7351746809413291, 0),
(48, 'MOCK001', 'Bob Johnson', 5, 'Incredible quality, highly recommend to everyone!', '2025-07-15 13:09:03.854639', 1, 0.6958059977760938, 0),
(49, 'MOCK001', 'Alice Brown', 2.5, 'It\'s okay, nothing special but gets the job done.', '2025-07-15 13:09:03.854640', 0, 0.6651660967092314, 0),
(50, 'MOCK001', 'Charlie Wilson', 4, 'Perfect product, exceeded all expectations!', '2025-07-15 13:09:03.854641', 1, 0.6665385526404196, 0),
(51, 'MOCK001', 'John Doe', 4.5, 'This product is absolutely amazing! Best thing ever! 5 stars!', '2025-07-16 12:45:57.701796', 1, 0.7503229099980595, 0),
(52, 'MOCK001', 'Jane Smith', 3, 'The product works as expected. Good quality for the price.', '2025-07-16 12:45:57.701802', 0, 0.7351746809413291, 0),
(53, 'MOCK001', 'Bob Johnson', 5, 'Incredible quality, highly recommend to everyone!', '2025-07-16 12:45:57.701804', 1, 0.6958059977760938, 0),
(54, 'MOCK001', 'Alice Brown', 2.5, 'It\'s okay, nothing special but gets the job done.', '2025-07-16 12:45:57.701805', 0, 0.6651660967092314, 0),
(55, 'MOCK001', 'Charlie Wilson', 4, 'Perfect product, exceeded all expectations!', '2025-07-16 12:45:57.701807', 1, 0.6665385526404196, 0),
(56, 'MOCK001', 'John Doe', 4.5, 'This product is absolutely amazing! Best thing ever! 5 stars!', '2025-07-16 12:50:11.164491', 1, 0.7503229099980595, 0),
(57, 'MOCK001', 'Jane Smith', 3, 'The product works as expected. Good quality for the price.', '2025-07-16 12:50:11.164496', 0, 0.7351746809413291, 0),
(58, 'MOCK001', 'Bob Johnson', 5, 'Incredible quality, highly recommend to everyone!', '2025-07-16 12:50:11.164497', 1, 0.6958059977760938, 0),
(59, 'MOCK001', 'Alice Brown', 2.5, 'It\'s okay, nothing special but gets the job done.', '2025-07-16 12:50:11.164497', 0, 0.6651660967092314, 0),
(60, 'MOCK001', 'Charlie Wilson', 4, 'Perfect product, exceeded all expectations!', '2025-07-16 12:50:11.164498', 1, 0.6665385526404196, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indexes for table `payments_payment`
--
ALTER TABLE `payments_payment`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `razorpay_order_id` (`razorpay_order_id`),
  ADD KEY `payments_payment_review_id_ef498e4b_fk_reviews_review_id` (`review_id`);

--
-- Indexes for table `reviews_review`
--
ALTER TABLE `reviews_review`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `payments_payment`
--
ALTER TABLE `payments_payment`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reviews_review`
--
ALTER TABLE `reviews_review`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `payments_payment`
--
ALTER TABLE `payments_payment`
  ADD CONSTRAINT `payments_payment_review_id_ef498e4b_fk_reviews_review_id` FOREIGN KEY (`review_id`) REFERENCES `reviews_review` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
