from django.db import models
from django.contrib.auth.models import User

# Create your models here.

# This model represents a single review scraped from a product page.
class Review(models.Model):
    # The product's unique ID (e.g., Amazon ASIN)
    product_id = models.CharField(max_length=100)
    # The name of the reviewer
    reviewer = models.CharField(max_length=100)
    # The rating given by the reviewer (e.g., 4.5 stars)
    rating = models.FloatField()
    # The text content of the review
    review_text = models.TextField()
    # The date the review was posted
    date = models.DateTimeField()
    # Whether the review is detected as fake (True/False)
    is_fake = models.BooleanField(default=False)
    # The confidence score from the ML model (0 to 1)
    confidence_score = models.FloatField(default=0.0)
    # Whether the review has been verified (e.g., paid for verification)
    verified = models.BooleanField(default=False)
    # Admin notes for manual verification
    admin_notes = models.TextField(blank=True, null=True, help_text="Notes from admin verification process")
    # Admin who verified the review
    verified_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='verified_reviews')
    # When the review was manually verified
    verified_at = models.DateTimeField(null=True, blank=True)
    # Whether this is a manual override of ML prediction
    manual_override = models.BooleanField(default=False, help_text="Indicates if admin manually overrode ML prediction")

    def __str__(self):
        # This method returns a readable string for each review
        return f"{self.reviewer} - {self.product_id} ({'Fake' if self.is_fake else 'Real'})"
    
    class Meta:
        ordering = ['-date']
        verbose_name = "Review"
        verbose_name_plural = "Reviews"
