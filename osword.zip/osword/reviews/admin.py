from django.contrib import admin
from django.contrib import messages
from django.utils.html import format_html
from django.urls import reverse
from django.http import HttpResponseRedirect
from django.utils import timezone
from django import forms
from .models import Review

class BulkVerificationForm(forms.Form):
    """Form for bulk verification actions"""
    admin_notes = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 3, 'cols': 40}),
        required=False,
        help_text="Optional notes about this verification action"
    )

@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('reviewer', 'product_id', 'rating', 'is_fake', 'confidence_score', 'verified', 'date', 'admin_verification_status')
    list_filter = ('is_fake', 'verified', 'rating', 'date', 'confidence_score', 'manual_override')
    search_fields = ('reviewer', 'product_id', 'review_text', 'admin_notes')
    readonly_fields = ('confidence_score', 'admin_verification_status', 'verified_by', 'verified_at')
    list_per_page = 20
    actions = ['mark_as_verified', 'mark_as_fake', 'mark_as_real', 'clear_verification', 'add_admin_notes']
    
    fieldsets = (
        ('Review Information', {
            'fields': ('product_id', 'reviewer', 'rating', 'review_text', 'date')
        }),
        ('Analysis Results', {
            'fields': ('is_fake', 'confidence_score', 'verified'),
            'classes': ('collapse',)
        }),
        ('Admin Verification', {
            'fields': ('admin_verification_status', 'admin_notes', 'verified_by', 'verified_at', 'manual_override'),
            'classes': ('collapse',),
            'description': 'Manual verification actions for administrators'
        }),
    )
    
    def get_queryset(self, request):
        return super().get_queryset(request).order_by('-date')
    
    def admin_verification_status(self, obj):
        """Display admin verification status with color coding"""
        if obj.verified:
            if obj.manual_override:
                return format_html(
                    '<span style="color: orange; font-weight: bold;">✓ Manual Override</span>'
                )
            else:
                return format_html(
                    '<span style="color: green; font-weight: bold;">✓ Verified</span>'
                )
        elif obj.is_fake:
            return format_html(
                '<span style="color: red; font-weight: bold;">✗ Fake (ML)</span>'
            )
        else:
            return format_html(
                '<span style="color: blue; font-weight: bold;">○ Real (ML)</span>'
            )
    admin_verification_status.short_description = 'Verification Status'
    
    def mark_as_verified(self, request, queryset):
        """Mark selected reviews as verified"""
        notes_text = f"Bulk verified by {request.user.username} - {timezone.now().strftime('%Y-%m-%d %H:%M')}"
        updated = queryset.update(
            verified=True, 
            verified_by=request.user, 
            verified_at=timezone.now(),
            admin_notes=notes_text
        )
        self.message_user(
            request,
            f'Successfully marked {updated} review(s) as verified.',
            messages.SUCCESS
        )
    mark_as_verified.short_description = "Mark selected reviews as verified"
    
    def mark_as_fake(self, request, queryset):
        """Manually mark selected reviews as fake"""
        notes_text = f"Bulk marked as fake by {request.user.username} - {timezone.now().strftime('%Y-%m-%d %H:%M')}"
        updated = queryset.update(
            is_fake=True, 
            verified=True, 
            verified_by=request.user, 
            verified_at=timezone.now(),
            manual_override=True,
            admin_notes=notes_text
        )
        self.message_user(
            request,
            f'Successfully marked {updated} review(s) as fake (manual verification).',
            messages.SUCCESS
        )
    mark_as_fake.short_description = "Mark selected reviews as fake (manual)"
    
    def mark_as_real(self, request, queryset):
        """Manually mark selected reviews as real"""
        notes_text = f"Bulk marked as real by {request.user.username} - {timezone.now().strftime('%Y-%m-%d %H:%M')}"
        updated = queryset.update(
            is_fake=False, 
            verified=True, 
            verified_by=request.user, 
            verified_at=timezone.now(),
            manual_override=True,
            admin_notes=notes_text
        )
        self.message_user(
            request,
            f'Successfully marked {updated} review(s) as real (manual verification).',
            messages.SUCCESS
        )
    mark_as_real.short_description = "Mark selected reviews as real (manual)"
    
    def clear_verification(self, request, queryset):
        """Clear manual verification from selected reviews"""
        updated = queryset.update(
            verified=False, 
            verified_by=None, 
            verified_at=None,
            manual_override=False,
            admin_notes=""
        )
        self.message_user(
            request,
            f'Successfully cleared verification from {updated} review(s).',
            messages.SUCCESS
        )
    clear_verification.short_description = "Clear verification from selected reviews"
    
    def add_admin_notes(self, request, queryset):
        """Add admin notes to selected reviews"""
        notes_text = f"Admin notes by {request.user.username} - {timezone.now().strftime('%Y-%m-%d %H:%M')}"
        updated = queryset.update(admin_notes=notes_text)
        self.message_user(
            request,
            f'Successfully added admin notes to {updated} review(s).',
            messages.SUCCESS
        )
    add_admin_notes.short_description = "Add admin notes to selected reviews"
    
    def get_list_display(self, request):
        """Customize list display based on user permissions"""
        list_display = list(super().get_list_display(request))
        if request.user.is_superuser:
            # Add admin-specific columns for superusers
            if 'admin_verification_status' not in list_display:
                list_display = list_display + ['admin_verification_status']
        return list_display
    
    def get_actions(self, request):
        """Customize available actions based on user permissions"""
        actions = super().get_actions(request)
        if not request.user.is_superuser:
            # Remove admin-specific actions for non-superusers
            if 'mark_as_fake' in actions:
                del actions['mark_as_fake']
            if 'mark_as_real' in actions:
                del actions['mark_as_real']
            if 'clear_verification' in actions:
                del actions['clear_verification']
            if 'add_admin_notes' in actions:
                del actions['add_admin_notes']
        return actions
