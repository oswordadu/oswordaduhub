import joblib
import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
import numpy as np

class FakeReviewDetector:
    def __init__(self, model_path='ml_model/fake_review_model.pkl', vectorizer_path='ml_model/tfidf_vectorizer.pkl'):
        """Initialize the fake review detector with trained model and vectorizer"""
        try:
            self.model = joblib.load(model_path)
            self.vectorizer = joblib.load(vectorizer_path)
            print("Model and vectorizer loaded successfully!")
        except FileNotFoundError:
            print("Model files not found. Please train the model first.")
            self.model = None
            self.vectorizer = None
    
    def preprocess_text(self, text):
        """Preprocess text for fake review detection"""
        if not text or pd.isna(text):
            return ""
        
        # Convert to lowercase
        text = text.lower()
        
        # Remove special characters and numbers
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        
        # Tokenize
        tokens = word_tokenize(text)
        
        # Remove stopwords
        stop_words = set(stopwords.words('english'))
        tokens = [token for token in tokens if token not in stop_words]
        
        # Stemming
        stemmer = PorterStemmer()
        tokens = [stemmer.stem(token) for token in tokens]
        
        return ' '.join(tokens)
    
    def detect_fake_review(self, review_text):
        """Detect if a review is fake or real"""
        if self.model is None or self.vectorizer is None:
            return {
                'is_fake': False,
                'confidence_score': 0.0,
                'error': 'Model not loaded'
            }
        
        try:
            # Preprocess the text
            processed_text = self.preprocess_text(review_text)
            
            # Vectorize the text
            text_vector = self.vectorizer.transform([processed_text])
            
            # Make prediction
            prediction = self.model.predict(text_vector)[0]
            confidence_score = np.max(self.model.predict_proba(text_vector))
            
            return {
                'is_fake': bool(prediction),
                'confidence_score': float(confidence_score),
                'processed_text': processed_text
            }
        
        except Exception as e:
            return {
                'is_fake': False,
                'confidence_score': 0.0,
                'error': str(e)
            }
    
    def batch_detect(self, review_texts):
        """Detect fake reviews for multiple texts"""
        results = []
        for text in review_texts:
            result = self.detect_fake_review(text)
            results.append(result)
        return results

# Import pandas for the preprocess_text function
import pandas as pd

# Global detector instance
detector = None

def get_detector():
    """Get or create the global detector instance"""
    global detector
    if detector is None:
        detector = FakeReviewDetector()
    return detector

def detect_single_review(review_text):
    """Detect if a single review is fake"""
    detector = get_detector()
    return detector.detect_fake_review(review_text)

def detect_multiple_reviews(review_texts):
    """Detect if multiple reviews are fake"""
    detector = get_detector()
    return detector.batch_detect(review_texts) 