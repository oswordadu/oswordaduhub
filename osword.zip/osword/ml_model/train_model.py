import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score
import joblib
import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer

# Download required NLTK data
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')

try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')

def preprocess_text(text):
    """Preprocess text for fake review detection"""
    if pd.isna(text):
        return ""
    
    # Convert to lowercase
    text = text.lower()
    
    # Remove special characters and numbers
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    
    # Tokenize
    tokens = word_tokenize(text)
    
    # Remove stopwords
    stop_words = set(stopwords.words('english'))
    tokens = [token for token in tokens if token not in stop_words]
    
    # Stemming
    stemmer = PorterStemmer()
    tokens = [stemmer.stem(token) for token in tokens]
    
    return ' '.join(tokens)

def create_synthetic_dataset():
    """Create a synthetic dataset for training since we don't have the actual Yelp dataset"""
    
    # Generate synthetic fake and real reviews
    fake_reviews = [
        "This product is absolutely amazing! Best thing ever! 5 stars!",
        "Incredible quality, highly recommend to everyone!",
        "Perfect product, exceeded all expectations!",
        "Outstanding service and amazing product!",
        "This is the best purchase I've ever made!",
        "Absolutely love it! Worth every penny!",
        "Fantastic product, couldn't be happier!",
        "Excellent quality and fast delivery!",
        "Amazing experience, highly satisfied!",
        "Perfect in every way! 10/10 would recommend!",
        "This product changed my life! Incredible!",
        "Best decision ever! Absolutely perfect!",
        "Outstanding quality and amazing features!",
        "Incredible value for money! Love it!",
        "Perfect product, exactly as described!",
        "Amazing service and fantastic product!",
        "This exceeded all my expectations!",
        "Incredible quality and fast shipping!",
        "Absolutely perfect! Highly recommend!",
        "Best product I've ever used!",
        "Outstanding experience! Love everything about it!",
        "Incredible features and amazing quality!",
        "Perfect for my needs! Highly satisfied!",
        "Amazing product, worth every penny!",
        "Excellent quality and great value!",
        "This is exactly what I was looking for!",
        "Fantastic product, highly recommend!",
        "Incredible service and amazing product!",
        "Perfect in every aspect! Love it!",
        "Outstanding quality and fast delivery!",
        "Amazing experience, couldn't be happier!"
    ]
    
    real_reviews = [
        "The product works as expected. Good quality for the price.",
        "It's okay, nothing special but gets the job done.",
        "Decent product, shipping was a bit slow though.",
        "Average quality, expected more for the price.",
        "The item arrived on time and works fine.",
        "Not bad, but could be better for the money.",
        "It's functional but the design could be improved.",
        "Decent product, some minor issues but overall okay.",
        "The quality is acceptable for the price point.",
        "Works as advertised, no major complaints.",
        "Average product, nothing exceptional.",
        "It's fine for basic use, but don't expect premium quality.",
        "The packaging was good, product is adequate.",
        "Decent value for money, meets basic expectations.",
        "The item works but could use some improvements.",
        "Average quality, shipping was prompt.",
        "It's functional but not outstanding.",
        "Decent product, some pros and cons.",
        "The quality is reasonable for the price.",
        "Works okay, nothing to write home about.",
        "Average experience, product is acceptable.",
        "It's fine for what it is, nothing special.",
        "Decent quality, meets basic requirements.",
        "The product works, but could be better.",
        "Average value, acceptable quality.",
        "It's okay for the price, nothing exceptional.",
        "Decent product, some minor flaws.",
        "The quality is adequate for basic needs.",
        "Works as expected, average experience.",
        "It's functional but not impressive.",
        "Decent value, acceptable quality.",
        "Average product, meets basic expectations."
    ]
    
    # Create DataFrame
    fake_df = pd.DataFrame({
        'review': fake_reviews,
        'label': 1  # 1 for fake
    })
    
    real_df = pd.DataFrame({
        'review': real_reviews,
        'label': 0  # 0 for real
    })
    
    # Combine datasets
    df = pd.concat([fake_df, real_df], ignore_index=True)
    
    return df

def train_model():
    """Train the fake review detection model"""
    
    print("Creating synthetic dataset...")
    df = create_synthetic_dataset()
    
    print("Preprocessing text data...")
    df['processed_text'] = df['review'].apply(preprocess_text)
    
    # Split the data
    X = df['processed_text']
    y = df['label']
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    print("Vectorizing text data...")
    # TF-IDF Vectorization
    tfidf = TfidfVectorizer(
        max_features=5000,
        ngram_range=(1, 2),
        min_df=2,
        max_df=0.95
    )
    
    X_train_vec = tfidf.fit_transform(X_train)
    X_test_vec = tfidf.transform(X_test)
    
    print("Training Logistic Regression model...")
    # Train Logistic Regression
    lr_model = LogisticRegression(random_state=42, max_iter=1000)
    lr_model.fit(X_train_vec, y_train)
    
    # Predictions
    y_pred_lr = lr_model.predict(X_test_vec)
    lr_accuracy = accuracy_score(y_test, y_pred_lr)
    
    print(f"Logistic Regression Accuracy: {lr_accuracy:.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred_lr))
    
    print("\nTraining Random Forest model...")
    # Train Random Forest
    rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_model.fit(X_train_vec, y_train)
    
    # Predictions
    y_pred_rf = rf_model.predict(X_test_vec)
    rf_accuracy = accuracy_score(y_test, y_pred_rf)
    
    print(f"Random Forest Accuracy: {rf_accuracy:.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred_rf))
    
    # Choose the better model (Random Forest usually performs better)
    if rf_accuracy > lr_accuracy:
        best_model = rf_model
        print(f"\nUsing Random Forest model (Accuracy: {rf_accuracy:.4f})")
    else:
        best_model = lr_model
        print(f"\nUsing Logistic Regression model (Accuracy: {lr_accuracy:.4f})")
    
    # Save the model and vectorizer
    print("Saving model and vectorizer...")
    joblib.dump(best_model, 'ml_model/fake_review_model.pkl')
    joblib.dump(tfidf, 'ml_model/tfidf_vectorizer.pkl')
    
    print("Model training completed successfully!")
    return best_model, tfidf

if __name__ == "__main__":
    train_model() 