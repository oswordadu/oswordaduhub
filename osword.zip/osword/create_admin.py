#!/usr/bin/env python
import os
import sys
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'fake_review_detector.settings')
django.setup()

from django.contrib.auth.models import User

def create_admin_user():
    """Create admin user with password 'admin123'"""
    try:
        # Check if admin user exists
        admin_user = User.objects.filter(username='admin').first()
        
        if admin_user:
            # Update existing admin user
            admin_user.set_password('admin123')
            admin_user.save()
            print("✅ Admin user updated with password: admin123")
        else:
            # Create new admin user
            admin_user = User.objects.create_user(
                username='admin',
                email='admin@example.com',
                password='admin123',
                is_staff=True,
                is_superuser=True
            )
            print("✅ Admin user created with password: admin123")
        
        print(f"Username: admin")
        print(f"Password: admin123")
        print(f"Email: admin@example.com")
        
    except Exception as e:
        print(f"❌ Error creating admin user: {e}")

if __name__ == '__main__':
    create_admin_user() 