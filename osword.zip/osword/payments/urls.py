from django.urls import path
from . import views

app_name = 'payments'

urlpatterns = [
    # path('verify/<int:review_id>/', views.verify_review_payment, name='verify_review'),
    # path('audit/<int:review_id>/', views.audit_review_payment, name='audit_review'),
    # path('webhook/', views.payment_webhook, name='webhook'),
    # path('success/', views.payment_success, name='success'),
    # path('failure/', views.payment_failure, name='failure'),
    path('paystack/', views.paystack_payment, name='paystack'),
] 