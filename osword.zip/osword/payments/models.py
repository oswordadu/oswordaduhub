from django.db import models
from reviews.models import Review

# This model represents a payment made for a review (e.g., for verification or audit)
class Payment(models.Model):
    # Choices for payment status
    PAYMENT_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
        ('cancelled', 'Cancelled'),
    ]
    # Choices for payment type
    PAYMENT_TYPE_CHOICES = [
        ('verification', 'Review Verification'),
        ('audit', 'Human Audit'),
    ]
    # The review this payment is for
    review = models.ForeignKey(Review, on_delete=models.CASCADE, related_name='payments')
    # The amount paid
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    # The currency (e.g., 'INR')
    currency = models.CharField(max_length=3, default='INR')
    # The type of payment (verification or audit)
    payment_type = models.CharField(max_length=20, choices=PAYMENT_TYPE_CHOICES)
    # The status of the payment
    status = models.CharField(max_length=20, choices=PAYMENT_STATUS_CHOICES, default='pending')
    # When the payment was created
    created_at = models.DateTimeField(auto_now_add=True)
    # When the payment was last updated
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        # This method returns a readable string for each payment
        return f"Payment {self.review.reviewer}"

    class Meta:
        # Order payments by most recent first
        ordering = ['-created_at']
