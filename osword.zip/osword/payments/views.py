from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
from django.conf import settings
from .models import Payment
from reviews.models import Review
import json
import os

# [REMOVED: Razorpay integration and logic. Ready for Paystack integration.]

def paystack_payment(request):
    """Render the Paystack payment page where the user can pay and be verified."""
    return render(request, 'payments/paystack_payment.html')
